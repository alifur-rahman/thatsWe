<?php

return array (
  'welcome2' => 'Willkommen in der Kommandozentrale für den perfekten Urlaub.',
);
