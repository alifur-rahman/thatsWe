<!-- resources/views/emails/offer-submission.blade.php -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e(__('messages.info_material')); ?></title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h2 class="mt-4"><?php echo e(__('messages.info_material')); ?></h2>
        <hr>

        <div class="row mt-4">
            <div class="col-md-6">
                <strong><?php echo e(__('messages.company_name')); ?>:</strong>
                <p><?php echo e($formData['companyName']); ?></p>
            </div>
            <div class="col-md-6">
                <strong><?php echo e(__('messages.travel_industry')); ?>:</strong>
                <p><?php echo e($formData['travelIndustry']); ?></p>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-md-6">
                <strong><?php echo e(__('messages.telephone')); ?>:</strong>
                <p><?php echo e($formData['telephone']); ?></p>
            </div>
            <div class="col-md-6">
                <strong><?php echo e(__('messages.website')); ?>:</strong>
                <p><?php echo e($formData['website']); ?></p>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-md-6">
                <strong><?php echo e(__('messages.contact_person_name')); ?>:</strong>
                <p><?php echo e($formData['contactPerson']); ?></p>
            </div>
            <div class="col-md-6">
                <strong><?php echo e(__('messages.address')); ?>:</strong>
                <p><?php echo e($formData['address']); ?></p>
            </div>
        </div>

        <div class="row mt-4">
            <div class="col-md-6">
                <strong><?php echo e(__('messages.city')); ?>:</strong>
                <p><?php echo e($formData['city']); ?></p>
            </div>
            <div class="col-md-6">
                <strong><?php echo e(__('messages.postal_code')); ?>:</strong>
                <p><?php echo e($formData['postalCode']); ?></p>
            </div>
        </div>

    </div>

    <!-- Bootstrap JS and Popper.js -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\Users\ASUS\Downloads\thatswe-main-updated-3\thatswe-main\resources\views/emails/offer-submission.blade.php ENDPATH**/ ?>