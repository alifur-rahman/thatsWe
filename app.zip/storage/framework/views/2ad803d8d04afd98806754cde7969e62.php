<?php $__env->startSection('content'); ?>

<section class="bg-200" id="offer">
    <div class="container">
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            </div>
        <?php endif; ?>
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong><?php echo e(session('success')); ?></strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>

        <?php endif; ?>
        <div class="card">
            <div class="card-body">
                <h2 class="text-center mb-2"><?php echo e(__('messages.company_info')); ?></h2>

                <form action="<?php echo e(route('submit-offer')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-4 offset-md-3">
                            <div class="mb-2">
                                <label for="companyName" class="form-label"><?php echo e(__('messages.company_name')); ?></label>
                                <input type="text" class="form-control" id="companyName" name="companyName" placeholder="<?php echo e(__('messages.your_company_name')); ?>">
                            </div>
                        </div>

                        <div class="col-md-2">
                            <div class="mb-2">
                                <label for="travelIndustry" class="form-label"><?php echo e(__('messages.travel_industry?')); ?></label>
                                <select class="form-control" id="travelIndustry" name="travelIndustry">
                                    <option value=""><?php echo e(__('messages.choose_one')); ?></option>
                                    <option value="yes"><?php echo e(__('messages.yes')); ?></option>
                                    <option value="no"><?php echo e(__('messages.no')); ?></option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 offset-md-3">
                            <div class="mb-2">
                                <label for="telephone" class="form-label"><?php echo e(__('messages.telephone')); ?></label>
                                <input type="tel" class="form-control" id="telephone" name="telephone" placeholder="<?php echo e(__('messages.your_telephone')); ?>">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4 offset-md-3">
                            <div class="mb-2">
                                <label for="contactPerson" class="form-label"><?php echo e(__('messages.name_of_contact_person')); ?></label>
                                <input type="text" class="form-control" id="contactPerson" name="contactPerson" placeholder="<?php echo e(__('messages.contact_person_name')); ?>">
                            </div>
                        </div>
                    </div>

                        <div class="row">
                            <div class="col-md-1 offset-md-3">
                                <div class="mb-2">
                                    <label for="postalCode" class="form-label"><?php echo e(__('messages.postal_code')); ?></label>
                                    <input type="text" class="form-control" id="postalCode" name="postalCode" placeholder="<?php echo e(__('messages.your_postal_code')); ?>">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="mb-2">
                                    <label for="city" class="form-label"><?php echo e(__('messages.city')); ?></label>
                                    <input type="text" class="form-control" id="city" name="city" placeholder="<?php echo e(__('messages.your_city')); ?>">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-4 offset-md-3">
                                <div class="mb-2">
                                    <label for="address" class="form-label"><?php echo e(__('messages.address')); ?></label>
                                    <input type="text" class="form-control" id="address" name="address" placeholder="<?php echo e(__('messages.your_address')); ?>">
                                </div>
                            </div>
                        </div>
                        <div class="row ">
                            <div class="col-md-4 offset-md-3">
                                <div class="mb-2">
                                    <label for="website" class="form-label"><?php echo e(__('messages.website')); ?></label>
                                    <input type="text" class="form-control" id="website" name="website" placeholder="<?php echo e(__('messages.your_website')); ?>">
                                </div>
                            </div>
                        </div>

                        <div class="col-md-12 text-center">
                            <div class="mt-2">
                                <button type="submit" class="btn btn-primary"><?php echo e(__('messages.submit')); ?></button>
                            </div>
                        </div>
                </form>
            </div>
        </div>
    </div>
</section>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Downloads\thatswe-main-updated-3\thatswe-main\resources\views/offer.blade.php ENDPATH**/ ?>