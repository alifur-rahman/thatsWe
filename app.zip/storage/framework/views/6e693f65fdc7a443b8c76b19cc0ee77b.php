<?php $__env->startSection('content'); ?>


<section class="bg-200" id="recommend">
    <div class="container">
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
            <strong>Whoops!</strong> There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            </div>
        <?php endif; ?>
        <?php if(session('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong><?php echo e(session('success')); ?></strong>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>

        <?php endif; ?>
        <div class="card">
            <div class="card-body">
                <h2 class="text-center mb-4"><?php echo e(__('messages.recommend_to_friend')); ?></h2>

                <form action="<?php echo e(route('submit-recommendation')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row justify-content-center">
                        <!-- Other form fields -->
                        <div class="col-md-5">
                            <div class="mb-2">
                                <label for="yourName" class="form-label"><?php echo e(__('messages.your_name')); ?></label>
                                <input type="text" class="form-control" id="yourName" name="yourName" placeholder="<?php echo e(__('messages.your_name')); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="row justify-content-center">
                        <div class="col-md-3">
                            <div class="mb-2">
                                <label for="personEmail1" class="form-label"><?php echo e(__('messages.person_email')); ?> #1</label>
                                <input type="email" class="form-control" id="personEmail1" name="personEmail1" placeholder="<?php echo e(__('messages.person_email')); ?> #1">
                            </div>
                        </div>
                    </div>

                    <div class="row justify-content-center">
                        <div class="col-md-3">
                            <div class="mb-2">
                                <label for="personEmail2" class="form-label"><?php echo e(__('messages.person_email')); ?> #2</label>
                                <input type="email" class="form-control" id="personEmail2" name="personEmail2" placeholder="<?php echo e(__('messages.person_email')); ?> #2">
                            </div>
                        </div>
                    </div>

                    <div class="row justify-content-center">
                        <div class="col-md-3">
                            <div class="mb-2">
                                <label for="personEmail3" class="form-label"><?php echo e(__('messages.person_email')); ?> #3</label>
                                <input type="email" class="form-control" id="personEmail3" name="personEmail3" placeholder="<?php echo e(__('messages.person_email')); ?> #3">
                            </div>
                        </div>
                    </div>
                    <div class="row justify-content-center">
                        <div class="col-md-12 text-center mt-3">
                            <div class="">
                                <button type="submit" class="btn btn-primary"><?php echo e(__('messages.send')); ?></button>
                            </div>
                        </div>
                    </div>


                        <!-- Add more email input fields if needed -->


                </form>

            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL\Achim\thatswe\resources\views/recommend.blade.php ENDPATH**/ ?>