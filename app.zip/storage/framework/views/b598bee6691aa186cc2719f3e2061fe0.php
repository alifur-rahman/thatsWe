<?php $__env->startSection('content'); ?>
<section class="py-7 py-lg-8" id="home">
    
    <!--/.bg-holder-->

    <div class="bg-holder d-xxl-block hero-bg"
        style="background-image: url(assets/img/illustration/220.png); background-position: right top; background-size: cover; height: 100vh;">

    </div>
    <!--/.bg-holder-->

    <div class="container">
        <div class="row align-items-center h-100 justify-content-center justify-content-lg-start">
            <div class="col-md-6 col-xxl-5 text-md-start text-center pb-3">
                <h1 class="fw-bold" style="line-height: 1.0;color: #323D9A;"><?php echo e(__('messages.welcome2')); ?></h1>
                <p class="fs-5 fw-bolder" style="color: #323D9A;"><?php echo e(__('messages.fulfill')); ?></p>
                <div class="d-flex flex-column flex-sm-row justify-content-center justify-content-md-start ">
                    <a class="btn btn-sm btn-primary me-1 mb-1 mb-sm-0" href="<?php echo e(url('/offer')); ?>?#offer"
                        role="button"><?php echo e(__('messages.get_info')); ?></a>
                    <a class="btn btn-sm btn-primary me-1" href="<?php echo e(url('/recommendation')); ?>#recommend"
                        role="button"><?php echo e(__('messages.recommendation')); ?></a>
                </div>
            </div>
        </div>
    </div>
    <div class="container text-center">
        <div class="row">
            <div class="col-md-5 col-xxl-5">
                <h2 style="color: black; margin-bottom:0;"><?php echo e(__('messages.about_us')); ?></h2>
                <p>
                    <?php echo e(__('messages.about_us_description')); ?>

                </p>
            </div>
        </div>

    </div>
</section>



<?php $__env->stopSection(); ?>


<?php $__env->startSection('styles'); ?>
<style>
    body,
    html {
        margin: 0;
        padding: 0;
        width: 100%;
        height: 100vh;
        overflow-x: hidden;
        overflow-y: hidden;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL\thatswe-main\resources\views/welcome.blade.php ENDPATH**/ ?>